# Certification Path
Go to [KB Certification Fast Track](https://kb.epam.com/display/EPMCACM/Fast+Track+-+AWS+Certification+Program) (On the STEP 2 - follow _Developer Associate_ instructions)

# Materials

## Certification materials in modules
Find "Optional: [Materials for AWS Certification Exam]" section and study materials. Study recommended materials in the following sections only: 
- "General materials ..."
- "AWS Certified Developer - Associate certification"

## Quiz's for self-check
* [ITExams](https://www.itexams.com/exam/AWS%20Certified%20Developer%20Associate)
* [ExamTopics](https://www.examtopics.com/exams/amazon/aws-certified-developer-associate/view/)
* [Quizizz (Type topic in search)](https://quizizz.com/admin)
* [TestGorilla (Type topic in search)](https://www.testgorilla.com/test-library/)
* [(PAID) Udemy test exams](https://www.udemy.com/topic/aws-certification/)

## Tips for exam
* [Exam tips](https://karansingh.gitbook.io/tutorialsdojo-wrong-answers/)
* [AWS Developer Associate Exam – What to Expect](https://digitalcloud.training/aws-developer-associate-exam-what-to-expect/)
* [Hacks on AWS Exam Preparation](https://digitalcloud.training/hacks-on-aws-exam-preparation/)
* [Tips & Strategies on how to confidently answer questions in your AWS Developer Associate Exam](https://www.youtube.com/watch?v=6u3RADFhsbA)

## Review of AWS Cloud Products
* [Cloud Products](https://aws.amazon.com/products/?hp=tile&so-exp=below&aws-products-all.sort-by=item.additionalFields.productNameLowercase&aws-products-all.sort-order=asc&awsf.re%3AInvent=*all&awsf.Free%20Tier%20Type=*all&awsf.tech-category=*all)

## Additional Materials
* [Resource with a lot of useful information](https://tutorialsdojo.com/)
* [AWS Cheat Sheets](https://tutorialsdojo.com/aws-cheat-sheets/)
* [Comparison of AWS services](https://tutorialsdojo.com/comparison-of-aws-services/)
