# AWS Certification Pathways
![](images/generalinfo.png)

## AWS Certification Pathways available after completing CloudX
* [AWS Certified Developer - Associate](./AWS_Certified_Developer_–_Associate)
* [AWS Certified SysOps - Associate](./AWS_Certified_SysOps_–_Associate)

## All AWS Certification Pathways
### Foundational:
<table style="table-layout: fixed; width: 100%;">
<thead>
	<tr>
		<th>AWS Original</th>
		<th>Epam Learn</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-cloud-practitioner/?ch=cta&amp;cta=header&amp;p=2">AWS Certified Cloud Practitioner</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=0590ef80-d2f9-41d0-8b2e-b75b57022f51">AWS Certification: Cloud Practitioner</a></td>
	</tr>
</tbody>
</table>


### Associate:

<table  style="table-layout: fixed; width: 100%;">
<thead>
	<tr>
		<th>AWS Original</th>
		<th>Epam Learn</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-solutions-architect-associate/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Solutions Architect – Associate</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=c24addb6-28aa-4efe-ad68-4112ae1780af">AWS Certification: Associate Solution Architect</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-sysops-admin-associate/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified SysOps Administrator - Associate</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=45cc37b5-d34f-4073-9ae1-f651ce94f5de">AWS Certification: Associate SysOps Administrator</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-developer-associate/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Developer - Associate</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=5a639a0c-4cdc-4875-a6d0-3c596c0331da">AWS Certification: Associate Developer</a></td>
	</tr>
</tbody>
</table>

### Professional:

<table style="table-layout: fixed; width: 100%;">
<thead>
	<tr>
		<th>AWS Original</th>
		<th>Epam Learn</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-solutions-architect-professional/?ch=sec&sec=rmg&d=1">AWS Certified Solutions Architect - Professional</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=4fde2896-a95d-41e1-8c58-13931c51b1d1">AWS Certification: Professional Solution Architect</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-devops-engineer-professional/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified DevOps Engineer - Professional</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=41162e40-28c7-43d3-9b64-88315df1a7fb">AWS Certification: Professional DevOps Engineer</a></td>
	</tr>
</tbody>
</table>



### Specialty:

<table style="table-layout: fixed; width: 100%;">
<thead>
	<tr>
		<th>AWS Original</th>
		<th>Epam Learn</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-advanced-networking-specialty/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Advanced Networking - Specialty</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=5071868d-56fd-48d0-b0cf-5708b1ce3f6f">AWS Certification: Advanced Networking - Specialty</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-data-analytics-specialty/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Data Analytics - Specialty</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=3c18ac12-e7da-4b68-a36c-592196765126">AWS Certification: Data Analytics - Specialty</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-database-specialty/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Database - Specialty</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=13018494-e05f-406d-b3d6-1de377b9ac48">AWS Certification: Database - Specialty</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-machine-learning-specialty/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Machine Learning - Specialty</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=442b1ac2-021a-4e8c-a483-41294f9e9f56">AWS Certification: Machine Learning - Specialty</a></td>
	</tr>
	<tr>
		<td><a href="https://aws.amazon.com/certification/certified-security-specialty/?ch=sec&amp;sec=rmg&amp;d=1">AWS Certified Security - Specialty</a></td>
		<td><a href="https://learn.epam.com/detailsPage?id=c0445377-3835-475f-8e70-bb8f365ec20a">AWS Certification: Security - Specialty</a></td>
	</tr>
</tbody>
</table>

### Special

<table>
<thead>
	<tr>
		<th>Epam Learn</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><a href="https://learn.epam.com/detailsPage?id=5c907593-da29-4537-80db-ab9c98e26a76">AWS Certification: Fast Track (Specialty/Professional levels)</a></td>
	</tr>
</tbody>
</table>

---

![](images/teamsicon.png)[Connect to Teams Channel for more info](https://teams.microsoft.com/dl/launcher/launcher.html?url=%2F_%23%2Fl%2Fchannel%2F19%3A00647d32337c417a8888bf36f625ac72%40thread.tacv2%2FGeneral%3FgroupId%3Dc0a1c15a-80a0-48bd-9afd-e53c4087d847%26tenantId%3Db41b72d0-4e9f-4c26-8a69-f949f367c91d&type=channel&deeplinkId=240ed751-0b4b-4999-8670-d8bb6d9a9837&directDl=true&msLaunch=true&enableMobilePage=true&suppressPrompt=true)

