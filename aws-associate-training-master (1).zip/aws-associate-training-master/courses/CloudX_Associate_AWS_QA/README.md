# CloudX Associate: AWS for Testers
- [Learn]()

## Modules
### Module 0: AWS Essentials for Developers
- [Theory](https://learn.epam.com/detailsPage?id=1841e875-a3a7-4809-9852-6c13d466c523)
### Module 1: Create AWS Account
- [Theory](./materials/01_create_account/README.md)
- [Practice](./tasks/01_create_account/README.md)
### Module 2: IAM
- [Theory](./materials/02_iam/README.md)
- [Practice](./tasks/02_iam/README.md)
### Module 3: EC2
- [Theory](./materials/03_ec2/README.md)
- [Practice](./tasks/03_ec2/README.md)
### Module 4: VPC
- [Theory](./materials/04_vpc/README.md)
- [Practice](./tasks/04_vpc/README.md)
### Module 5: S3
- [Theory](./materials/05_s3/README.md)
- [Practice](./tasks/05_s3/README.md)
### Module 6: Databases
- [Theory](./materials/06_databases/README.md)
- [Practice](./tasks/06_databases/README.md)
### Module 7: SNS,SQS
- [Theory](./materials/07_sns_sqs/README.md)
- [Practice](./tasks/07_sns_sqs/README.md)
### Module 8: Serverless Basics
- [Theory](./materials/08_serverless/README.md)
- [Practice](./tasks/08_serverless/README.md)
### Module 9: Monitoring and Logging
- [Theory](./materials/09_monitoring/README.md)
- [Practice](./tasks/09_monitoring/README.md)
### Module 10: Remove All Created Resources from AWS Account
- Remove all created resources and notify your expert.
