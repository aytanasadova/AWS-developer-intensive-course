# Task #7 - SNS, SQS

# Context 
You will work with sample web API **CloudXImage** application which allows user to manage images in s3 bucket.

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudximage.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the **cloudximage** CDK stack: [deployment instructions](../../applications/docs/cloudximage.md)

## 2. Deployment validation
Create manual / automated deployment validation test suite that covers the following requirements:
* Application uses SNS topic to subscribe, unsubscribe users, list existing subscriptions, and send e-mail messages to subscribers about upload and delete image events, in a readable format (not JSON).
* Application uses SQS queue to publish event messages. SNS topic uses SQS queue as a source of messages for notifications.
* Application should have access to SQS queue and SNS topic via IAM roles.

SNS topic requirements:
* Name: cloudximage-TopicSNSTopic{unique id}
* Type: standard
* Encryption: disabled
* Tags: cloudx

SQS queue requirements:
* Name: cloudximage-QueueSQSQueue{unique id}
* Encryption: disabled
* Type: standard
* Tags: cloudx
* Dead-letter queue: no

### Testing Tools:
* Application OpenAPI documentation
* AWS Console
* AWS SDK (for automated tests).

## 3. Application functional validation
Write manual / automated functional test suite that covers the following requirements:
* user is able to subscribe to notifications about application events via provided email address
* user has to confirm subscription after receiving confirmation email
* subscribed user receives notifications about images events (image is uploaded, image is deleted)
* notification contains correct image metadata information and download link
* user is able to download image ising download link from notification
* user is able to unsubscribe from notifications
* unsubscribed user does not receive notifications
* is it possible to view all existing subscriptions using {base URL}/image GET API call

Execute test cases and verify that requirements are met.

### 4. Regression testing
Deploy version 4 of **CloudXImage** application [deployment instructions](../../applications/docs/cloudximage.md).
Execute deployment and functional validation test suites against new application version deployment.
Find regression issue and create root cause report.

## 5. Environment clean-up
Delete application stack and clean up environment: [clean-up intructions](../../applications/docs/cloudximage.md)

## 6. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
