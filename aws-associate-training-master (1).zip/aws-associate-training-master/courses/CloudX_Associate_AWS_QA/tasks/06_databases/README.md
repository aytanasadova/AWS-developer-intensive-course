# Task #6 - RDS

# Context 
You will work with sample web API **CloudXImage** application which allows user to manage images in S3 bucket.

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudximage.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the **cloudximage** CDK stack: [deployment instructions](../../applications/docs/cloudximage.md)

## 2. Deployment Validation:
Create manual / automated deployment validation test suite that covers the following requirements:
* Application database (MySQL RDS instance) is deployed in private subnet and should be accessible only from application public subnet, but not from public internet.
* Application should have access to MySQL RDS via IAM role.

RDS Instance requirements:
* Instance type: db.t3.micro
* Multi-AZ: no
* Storage size: 100 GiB
* Storage type: General Purpose SSD (gp2)
* Encryption: not enabled
* Instance tags: cloudx
* Database type: MySQL
* Database version: 8.0.11

### Testing tools:
* AWS Console
* AWS SDK (for automated tests).
* SSH client
* Infrastructure testing libraries (e.g. TestInfra)
* MySQL database client

Execute test cases and verify that requirements are met.

## 3. Application functional validation
Create manual / automated deployment validation test suite that covers the following requirements:
1. uploaded image metadata is stored in MySQL RDS database:
   - image key
   - image size
   - image type
   - last modification date and time
2. image metadata is returned by {base URL}/image/{image_id} GET request
3. image metadata for deleted image is also deleted from database

### Testing tools:
* Application OpenAPI documentation
* MySQL database client (NB: database is accessible only from application instance, not from internet)
* AWS Console
* AWS SDK (for automated tests).

Execute test cases and verify that requirements are met.

### 4. Regression testing
Deploy version 3 of **CloudXImage** application [deployment instructions](../../applications/docs/cloudximage.md).
Execute deployment and functional validation test suites against new application version deployment.
Find regression issue and create root cause report.

## 5. Environment clean-up
Delete application stack and clean up environment: [clean-up intructions](../../applications/docs/cloudximage.md)

## 6. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
