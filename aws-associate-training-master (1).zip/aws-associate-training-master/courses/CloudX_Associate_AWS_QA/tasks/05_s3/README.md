# Task #5 - S3

# Context 
You will work with sample web API **CloudXImage** application which allows user to manage images in s3 bucket.

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudximage.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the **cloudximage** CDK stack: [deployment instructions](../../applications/docs/cloudximage.md)

## 2. Deployment Validation:
Create manual / automated deployment validation test suite that covers the following requirements:
* Application is deployed in public subnet and should be accessible by HTTP from internet via Internet gateway by public IP addess and FQDN.
* Application instance should be accessible by SSH protocol.
* Application should have access to S3 bucket via IAM role.

S3 bucket requirements:
* Name: cloudximage-imagestorebucket{unique id}
* Tags: cloudx
* Encryption: disabled
* Versioning: disabled
* Public access: no

### Testing tools:
* Application OpenAPI documentation
* Postman
* SSH client
* AWS Console
* AWS SDK (for automated tests).

Execute test cases and verify that requirements are met.

## 3. Application functional validation
Create manual / automated test suite that covers the following application API functions:
* upload images to S3 bucket
* download image from s3 bucket
* view list of uploaded images
* delete image from s3 bucket

### Testing tools:
* Application OpenAPI documentation
* Postman
* AWS Console
* AWS S3 SDK (for automated tests). 

Execute test cases and verify that requirements are met.

### 4. Regression testing
Deploy version 2 of **CloudXImage** application [deployment instructions](../../applications/docs/cloudximage.md).
Execute deployment and functional validation test suites against new application version deployment.
Find regression issue and create root cause report.

## 5. Environment clean-up
Delete application stack and clean up environment: [clean-up intructions](../../applications/docs/cloudximage.md)

## 6. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
