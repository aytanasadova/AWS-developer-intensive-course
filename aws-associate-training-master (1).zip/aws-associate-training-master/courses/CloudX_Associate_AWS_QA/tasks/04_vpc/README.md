# Task #4 - VPC

# Context
You will work with sample web API application **CloudXInfo** which provides information from EC2 metadata:

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudxinfo.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the ****cloudxinfo** CDK stack: [deployment instructions](../../applications/docs/cloudxinfo.md)

## 2. Deployment validation
Create manual / automated deployment validation test suite that covers the following requirements:
VPC configuration:
* Application should be deployed in non-default VPC with has 2 subnets: public and private.
* VPC CIDR Block: 10.0.0.0/16
* VPC tags: Name, cloudx

Subnets and routing configuration:
* Public instance should be accessible from internet by Internet Gateway.
* Public instance should have access to private instance.
* Private instance should not be accessible from internet.
* Private instance should have access to internet via NAT Gateway.
* Private instance should not be accessible from public internet.

### Testing Tools:
* AWS Console
* AWS SDK (for automated tests).
* Application OpenAPI documentation
* Postman
* CURL command
* SSH client

Execute test cases and verify that requirements are met.

### 3. Regression testing
Deploy version 3 of **CloudXInfo** application [deployment instructions](../../applications/docs/cloudxinfo.md).
Execute deployment and functional validation test suites against new application version deployment.
Find regression issue and create root cause report.

## 4. Environment clean-up
Delete **cloudxinfo** application stack and clean up environment:[clean-up intructions](../../applications/docs/cloudxinfo.md)

## 5. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
