# Task #9 - Monitoring and logging

# Context 
You will work with sample web API **CloudXServerless** application which allows user to manage images in s3 bucket.

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudxserverless.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the **cloudxserverless** CDK stack: [deployment instructions](../../applications/docs/cloudxserverless.md)

## 2. Deployment validation
Create manual / automated deployment validation test suite that covers the following requirements:
* Application EC2 instance has CloudWatch integration.
* CloudInit logs should be collected in CloudWatch logs.
* Application messages should be collected in CloudWatch logs.
* Event handler logs should be collected in CloudWatch logs. 
* CloudTrail is enabled for Serverless stack and collects logs about AWS services access.

CloudWatch requirements (LogGroups):
* /aws/lambda/cloudxserverless-EventHandlerLambda{unique id}: for the event handler lambda function, in the same region as the stack
* /var/log/cloudxserverless-app: for the application deployed on the EC2 instance (by instance ID), in the same region as the stack
* /var/log/cloud-init: for the cloud-init logs of the EC2 instance (by instance ID), in the us-east-1 region

CloudTrail trail requirements:
* Name: cloudxserverless-Trail{unique id}
* Multi-region: yes
* Log file validation: enabled
* SSE-KMS encryption: not enabled
* Tags: cloudx


### Testing Tools:
* Application OpenAPI documentation
* AWS Console
* AWS SDK (for automated tests).

### 3. Monitoring and logging validation
Create additional test suite that covers following requirements related to application monitoring and logging:

1. Cloudxserverless-EventHandlerLambda{unique_id} log group:
* Each notification event processed by Event Handler Lambda is logged in CloudWatch logs.
* For each notification image information (object key, object type, object size, modification date, download link) 
is logged in Event Handler Lambda logs in CloudWatch logs.

2. Cloudxserverless-app log group:
* All HTTP API requests processed by application is logged in CloudWatch logs.

### Testing Tools:
* Application OpenAPI documentation
* AWS Console
* AWS SDK (for automated tests).

## 4. Environment clean-up
Delete application stack and clean up environment: [clean-up intructions](../../applications/docs/cloudxserverless.md)

## 5. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
