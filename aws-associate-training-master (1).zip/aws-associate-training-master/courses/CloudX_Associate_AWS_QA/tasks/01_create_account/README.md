# Task #1 – Account creation, roles, billing, alerting

# Sub-tasks
## 1.  Create AWS Account
Follow this [link](https://aws.amazon.com/premiumsupport/knowledge-center/create-and-activate-aws-account/) to create account. Note, accounts are usually activated within a few minutes, but the process might take up to 24 hours.

## 2. Secure account
Follow general AWS recommendations. Here mentioned some of them, but feel free to read full article ([best-practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)):
* Lock away your AWS account root user access keys ([reference](https://docs.aws.amazon.com/IAM/latest/UserGuide/getting-started_create-admin-group.html))
* Avoid using AWS account root user
* Grant least privilege
* Use permissions with AWS managed policies
* Configure a strong password policy for your users
* Enable MFA

## 3. Set Budgets/Alerts
Avoid surprising charges, so control cost carefully:
* Ensure free tier notifications are enabled ([link](https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/tracking-free-tier-usage.html))
* Setup budget reached notifications (ex. 40%, 80%, 100%) manually (via console). Alert should be sent to your email.


# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
