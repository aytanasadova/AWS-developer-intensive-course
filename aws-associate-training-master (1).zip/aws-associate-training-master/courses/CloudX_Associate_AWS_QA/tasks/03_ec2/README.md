# Task #3 - EC2

# Context 
You will work with sample web API application **CloudXInfo** which provides information from EC2 metadata:

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudxinfo.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the **cloudxinfo** CDK stack: [deployment instructions](../../applications/docs/cloudxinfo.md)

## 2. Deployment validation
Create manual / automated deployment validation test suite that covers following requirements:
* 2 application instances should be deployed: public and private.

Each EC2 instance should have the following configuration:
* Instance type: t2.micro
* Instance tags: Name, cloudx 
* Root block device size: 8 GB
* Instance OS: Amazon Linux
* Public instance should have public IP assigned.
* Private instance should not have public IP assigned.

Security groups configuration:
* Public instance should be accessible from internet by SSH (port 22) and HTTP (port 80) only.
* Private instance should be accessible only from public instance by SSH and HTTP protocols only.
* Private and public instances should have access to internet.

### Testing Tools:
* AWS Console
* AWS SDK (for automated tests).
* Application OpenAPI documentation
* Postman / CURL
* SSH client

## 3. Application functional validation
Create manual / automated test suite that covers the following requirements:
1. Application API endpoint should respond with correct instance information from ec2 metadata:
   * aws region
   * availability zone
   * instance private ip.

Should be verifired both for public and private instances.

### Testing Tools:
* Application OpenAPI documentation
* Postman
* AWS Console
* AWS SDK (for automated tests).

Execute test cases and verify that requirements are met.

### 4. Regression testing
Deploy version 2 of **CloudXInfo** application [deployment instructions](../../applications/docs/cloudxinfo.md).
Execute deployment and functional validation test suites against new application version deployment.
Find regression issue and create root cause report.

## 5. Environment clean-up
Delete **cloudxinfo** application stack and clean up environment: [clean-up intructions](../../applications/docs/cloudxinfo.md)

## 6. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
