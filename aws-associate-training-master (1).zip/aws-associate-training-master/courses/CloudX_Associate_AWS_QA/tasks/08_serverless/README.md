# Task #8 - Serverless Basics

# Context 
The new version of **CloudXImage** application - called **CloudXServerless** - is available.

This **Serveless Image** application now uses more serverless AWS services: 
* AWS Lambda
* Dynamo DB
* AWS SQS
* AWS SNS

Application is to be deployed by CDK stack in selected AWS region (indicated in aws config).

[Application deployment architecture](../../applications/docs/cloudxserverless.md)

After deployment application OpenAPI UI Endpoint should be available by this URL:
* http:{<i>instance public ip or fqdn</i>}/api/ui

# Prerequisites
[Environment configuration](../../applications/README.md)

# Sub-tasks:
## 1. Deploy ImageInfo application
Deploy the **cloudxserverless** CDK stack: [deployment instructions](../../applications/docs/cloudxserverless.md)

## 2. Deployment validation
Create manual / automated deployment validation test suite that covers the following requirements:
* Application database is replaced with Dynamo DB table.
* DynamoDB table should store the following image metadata information:
object creation-time, object last modification date-time, object key, object size, object type.
* SNS topic is used to subscribe, unsubscribe users, list existing subscriptions, and send messages to subscribers about upload and delete image events. 
* Application uses SQS queue to publish event messages. 
* Lambda function is subscribed to SQS queue to filter and put event messages to SNS topic.
* Application should have access to S3 bucket, Dynamo DB, SQS queue and SNS topic instance via IAM roles.

AWS Lambda requirements:
* Lambda Trigger: SQS Queue
* Lambda application logs are are stored in CloudWatch log group (aws/lambda/cloudxserverless-EventHandlerLambda{unique id})
* Memory: 128 MB
* Ephemeral storage: 512 MB
* Timeout: 3 sec.
* Tags: cloudx

Dynamo DB Table requirements:
* Name: cloudxserverless-DatabaseImagesTable{unique id}
* Global secondary indexes: not enabled
* Provisioned read capacity units: 5
* Provisioned write capacity units: 1
* Time to Live: disabled
* Tags: cloudx

### Testing Tools:
* Application OpenAPI documentation
* AWS Console
* AWS SDK (for automated tests)
* DynamoDB client

## 3. Application regression testing
Adjust functional test cases developed in module 6 and 7 to new application architecture.

Execute functional test cases developed in module 6 and 7 and verify that there are no functional regression issues.

### Testing Tools:
* Application OpenAPI documentation
* Dynamo DB client
* AWS Console
* AWS SDK (for automated tests).

## 4. Environment clean-up
Delete application stack and clean up environment: [clean-up intructions](../../applications/docs/cloudxserverless.md)

## 5. Submit results
Upload home task artifacts (screenshots, test cases / link to automated tests code in git repository) to Learn Portal and change task status to „Needs Review”.

# IMPORTANT THINGS TO KEEP IN MIND
1. Once you create AWS Account -> Setup Multi-factor Authentication 
2. Do NOT share your account 
3. Do NOT commit your account Credentials into the Git 
4. Terminate/Remove all created resources/services once you finish Module 
5. Please Do not forget to delete NAT Gateway if you used it. 
6. Do NOT keep instance running if you don’t use it 
7. Carefully keep track of billing and working instances so you don't exceed limits
