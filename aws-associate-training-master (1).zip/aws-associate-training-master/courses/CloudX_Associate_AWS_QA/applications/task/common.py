from typing import List, Literal, Optional
import platform

CDKCommand = Literal["deploy", "destroy"]

STACKS = ['cloudxiam', 'cloudxinfo', 'cloudximage', 'cloudxserverless']


def _validate_stack(stack: str):
    if stack not in STACKS:
        raise ValueError(
            "There is no stack like '{}', possible stack: {}".format(stack, ", ".join(STACKS)))

def run_command(c, cmd: List[str]):
    c.run(" ".join(cmd), pty=platform.system() != 'Windows', echo=True)

def run_cdk(c, command: CDKCommand, stack: str, profile: Optional[str] = None, context: Optional[dict] = None, force: Optional[bool] = False):
    _validate_stack(stack)
    cmd = ["cdk"]
    if profile:
        cmd.append(f"--profile {profile}")
    cmd.append(command)
    cmd.append(stack)
    if force:
        cmd.append("--force")
    
    if not context:
        context = {}    
    context['stack'] = stack
    cmd.append(" ".join([f"--context {k}={v}" for k, v in context.items()]))
    run_command(c, cmd)

def help(commands: Optional[dict] = {}):
    return {
        'profile': 'The AWS profile to use, the default one will be used if empty.',
        **commands
    }