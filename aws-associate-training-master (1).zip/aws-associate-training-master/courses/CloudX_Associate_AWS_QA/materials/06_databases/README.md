# Task #6 – RDS

## What to read/watch beforehand
• [[AWS docs] What is RDS?](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Welcome.html)
* read the root article
* look through the rest of the docs table of contents – you might want get back to it during the practical task implementation

• [[AWS docs] Getting started with RDS](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_GettingStarted.html)
* choose one engine that you prefer, but ensure it’s eligible for the free-tier (at the moment of this writing, the only engine which is not free was Aurora)

• [[AWS docs] RDS best practices](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_BestPractices.html)

• [[AWS docs] Using RDS with VPC](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_VPC.html)

• [[AWS docs] FAQ](https://aws.amazon.com/rds/faqs/?nc=sn&loc=5)

What answers to know
1. What is RDS? What engines does it support?
2. What is RDS pricing?
3. What is read replica in RDS and how it works?
4. What RDS operational (maintenance, monitoring) practices do you know?
5. What RDS capacity planning best practices do you know?
6. What RDS testing and profiling best practices do you know?
7. What are the advantages of RDS over manually managed databases?
8. What is the difference between multi-AZ deployment and read replicas in RDS?
9. What security features does RDS provide?
10. What is AWS Aurora?
