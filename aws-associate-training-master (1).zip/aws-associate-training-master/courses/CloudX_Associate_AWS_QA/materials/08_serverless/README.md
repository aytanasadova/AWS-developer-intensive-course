# Task #8 – Serverless Basics

## What to read/watch beforehand
• [[AWS docs] What is Lambda?](https://docs.aws.amazon.com/lambda/latest/dg/welcome.html)
* read the root article
* look through the rest of the docs table of contents – you might want get back to it during the practical task implementation

• [[AWS docs] Lambda features](https://aws.amazon.com/lambda/features/)

• [[AWS docs] Getting started with Lambda](https://docs.aws.amazon.com/lambda/latest/dg/getting-started.html)

• [[AWS docs] Lambda best practices](https://docs.aws.amazon.com/lambda/latest/dg/best-practices.html)

• [[AWS docs] Lambda pricing](https://aws.amazon.com/lambda/pricing/)

• [[AWS docs] What is API Gateway?](https://docs.aws.amazon.com/apigateway/latest/developerguide/welcome.html)

• [[AWS docs] API Gateway glossary](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-basic-concept.html)

• [[AWS docs] API Gateway pricing](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-pricing.html)

• [[AWS docs] What is Amazon DynamoDB?](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Introduction.html)

• [[AWS docs] Accessing DynamoDB](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/AccessingDynamoDB.html)

• [[AWS docs] Getting started with DynamoDB](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/GettingStartedDynamoDB.html)

• [[AWS docs] Monitoring and logging](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/monitoring.html)

• [[AWS docs] Best practices for designing and architecting with DynamoDB](https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/best-practices.html)


## What answers to know
1. What ways of triggering a Lambda do you know?
2. What is the contract of Lambda function?
3. What is Lambda pricing?
4. How is it possible to test Lambda code without actually running it in AWS?
5. Which code libraries/frameworks are reasonable to use in Lambda?
6. How Lambda instances are reused? How to prepare the Lambda code for that?
7. What programming languages does Lambda support?
8. What is the difference between synchronous and asynchronous Lambda invocations?
9. What is Lambda concurrency?
10. What kinds of Lambda concurrency allocations are there?
11. What AWS resources can Lambda access? How?
12. What are the advantages of API Gateway endpoints over traditional web applications? 
13. What are the typical API Gateway use cases?
14. What is API Gateway pricing?
15. When you want to make sure you get the latest data from DynamoDB, which type of read will you use? 
16. Can you make your DynamoDB highly available? If yes, how?
