# Task #7 – SNS/SQS

## What to read/watch beforehand
• [[AWS docs] What is SNS?](https://docs.aws.amazon.com/sns/latest/dg/welcome.html)
* read the root article
* look through the rest of the docs table of contents – you might want get back to it during the practical task implementation

• [[AWS docs] SNS email subscription example (AWS Console)](https://docs.aws.amazon.com/sns/latest/dg/sns-getting-started.html)
* read the root article
* look through the rest of the docs table of contents – you might want get back to it during the practical task implementation

• [[AWS docs] SNS CLI](https://docs.aws.amazon.com/cli/latest/reference/sns/index.html)

• [[AWS docs] What is SQS?](https://docs.aws.amazon.com/sns/latest/dg/sns-getting-started.html)

• [[AWS docs] Common SNS scenarios](https://docs.aws.amazon.com/sns/latest/dg/sns-common-scenarios.html)

• [[AWS docs] SNS security](https://docs.aws.amazon.com/sns/latest/dg/sns-security.html)

• [[AWS docs] SNS pricing](https://aws.amazon.com/sns/pricing/)

• [[AWS docs] SQS pricing](https://aws.amazon.com/sqs/pricing/)

• [[AWS docs] SQS FAQ](https://aws.amazon.com/sqs/faqs/?nc=sn&loc=5)

• [[AWS docs] SNS FAQ](https://aws.amazon.com/sns/faqs/?nc1=h_ls)


## What answers to know
1. What messaging patterns do SNS and SQS implement?
2. What delivery protocols does SNS support?
3. How large SQS messages can be? What happens when that limit is exceeded?
4. What are the typical scenarios for using SQS?
5. What’s the difference between standard and FIFO queues in SQS?
6. What is SNS pricing?
7. What is SQS pricing?
8. What are SNS security best practices?
9. What are the security features supported by SNS/SQS?
10. What is the anatomy of an SNS message?
11. What can SNS do in case of failing messages?
12. What is SNS message filtering?
13. How is it possible to monitor SNS delivery process?
14. What is message lifecycle in SQS?
15. What’s the difference between short and long polling in SQS? 16. What messaging brokers are API-compatible with SQS?
