# Task #5 – S3

## What to read/watch beforehand
• [[AWS docs] What is AWS S3?](https://docs.aws.amazon.com/AmazonS3/latest/dev/Welcome.html)
* read the index article
* navigate through the rest of the table of contents because you might want to consult it later when facing concrete tech questions

• [[AWS docs] Getting started with S3](https://docs.aws.amazon.com/AmazonS3/latest/gsg/GetStartedWithS3.html)

• [[AWS docs] S3 FAQs](https://aws.amazon.com/s3/faqs/)

• [[Video] Introduction to S3](https://www.youtube.com/watch?v=_I14_sXHO8U)

• [[Video] An S3 tutorial for beginners](https://www.youtube.com/watch?v=XGcoeEyt2UM)

• [[AWS docs] Amazon S3 Storage Classes](https://aws.amazon.com/s3/storage-classes/)

• [[AWS docs] S3 Object lifecycle management](https://docs.aws.amazon.com/AmazonS3/latest/dev-retired/object-lifecycle-mgmt.html)

• [[AWS docs] S3 Protecting data using encryption.](https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingEncryption.html)

• [[AWS docs] FAQ](https://aws.amazon.com/s3/faqs/?nc=sn&loc=5)


## What answers to know
1. What are buckets in S3?
2. What does S3 replication do? What is it for?
3. What steps are required to gain AWS CLI access to an S3 bucket?
4. How is it possible to control access to S3 resources?
5. What are versions in S3? What does it mean to delete an object in S3 when versioning is enabled?
6. How is it possible to optimize cost of S3 resources?
7. How nested file hierarchies are represented in S3?
8. What does S3 store inside its objects?
9. Why S3 is better than a physically maintained file server?
         