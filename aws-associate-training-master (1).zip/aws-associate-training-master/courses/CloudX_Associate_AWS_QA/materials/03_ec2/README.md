# Task #3 – EC2

## What to read/watch beforehand
• [[AWS docs] What is EC2?](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/concepts.html)
* read the root article
* briefly look through the rest of the table of contents – you might want to get back to that in case you have more detailed tech questions later

• [[AWS docs] Regions and availability zones](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-regions-availability-zones.html)

• [[AWS docs] Setting up with EC2](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/get-set-up-for-amazon-ec2.html)

• [[AWS docs] EC2 best practices](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-best-practices.html)

• [[Video, optional] Introduction to EC2](https://www.youtube.com/watch?v=KpVNEzpvaY0)

• [[AWS docs] FAQ](https://aws.amazon.com/ec2/faqs/?nc=sn&loc=5)

• [[SSH on Windows] How to use PuTTy on Windows](https://www.ssh.com/academy/ssh/putty/windows)

• [[SSH troubleshoot] Stackoverflow Thread](https://stackoverflow.com/questions/9270734/ssh-permissions-are-too-open-error)


## What to save money on
* Make sure to remove the EC2 instance manually created throughout the sub-tasks 1-2.
* Remove EBS volume created in the sub-task 3.
* Configure the auto-scaling group to scale between 0-1 instances. Also, make sure to set the desired
instance count in it to 0 while you’re not working with EC2.

## What answers to know
1. What hardware is offered by EC2?
2. What provisioning/billing options are available with EC2?
3. What is EBS?
4. What types of volumes are offered by EC2?
5. What is the difference between AMI and snapshot in terms of EC2?
6. What are regions and availability zones in AWS?
7. How is it possible to install/configure software on a EC2 instance?
8. What keys are created for each EC2 instance? What for?
9. What happens to EC2 instances when they are stopped and started vs re-started?
10. What is the difference between IAM roles and EC2 (VPC) security groups?
11. Is it possible to decrease the size of an existing EBS volume?
12. Is it possible to reuse a EBS volume for multiple instances?
13. How is it possible to get such metadata as current region/AZ from within a running EC2 instance?
14. What are the available elastic load balancer types? What is the key difference between them?
15. What are the key events in EC2 instance lifecycle?
16. How does load balancing works? What are its core components?
17. How is it possible to grant a EC2 instance permissions to access certain AWS resources like S3? 18. What is auto-scaling? How is it related to load balancing?
