# Task #2 - IAM

## What to read/watch beforehand
• [[AWS docs] Intro to IAM](https://docs.aws.amazon.com/IAM/latest/UserGuide/introduction.html)

• [[AWS docs] IAM best practices](https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html)

• [[AWS docs] Access evaluation rules](https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html)

• [[Video] AWS re:Invent 2015: IAM Best Practices to Live By (SEC302)](https://www.youtube.com/watch?v=_wiGpBQGCjU&feature=youtu.be)

• [[Video] AWS IAM Tutorial | Identity And Access Management (IAM) | AWS Training Videos | Edureka](https://www.youtube.com/watch?v=UqKWHZ36yEM)

• [[AWS docs] What is AWS CLI?](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-welcome.html)

* Configuration basics
* Configuration and credential file settings
* Named profiles

• [[AWS docs] IAM FAQ](https://aws.amazon.com/iam/faqs/?nc=sn&loc=5)


## What answers to know
1. What is IAM?
2. What are the typical use case scenarios for IAM?
3. What are user groups and security groups in AWS? What’s the difference?
4. What are IAM policies?
5. What is EC2 and S3?
6. How to allow a user to programmatically access AWS resources?
7. What is the allow/deny priority order when policies are configured on different levels (group, user,
etc.)?
8. What ways of managing permissions for a given user do you know?
9. What places can be used by AWS CLI to gather credentials and settings?
10. What output formats does AWS CLI support?
        