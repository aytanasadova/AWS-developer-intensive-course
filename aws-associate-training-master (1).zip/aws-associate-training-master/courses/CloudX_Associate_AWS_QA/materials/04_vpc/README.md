# Task #4 – VPC

## What to read/watch beforehand
• [[web article] Subnets and CIDR](https://www.digitalocean.com/community/tutorials/understanding-ip-addresses-subnets-and-cidr-notation-for-networking) – must understand before doing anything with VPC

• [[AWS docs] What is AWS VPC?](https://www.digitalocean.com/community/tutorials/understanding-ip-addresses-subnets-and-cidr-notation-for-networking)
* read the root article
* briefly look through the table of contents – you might want to get back to clarify concrete tech questions

• [[web article] AWS Routing 101 (medium.com)](https://medium.com/@mda590/aws-routing-101-67879d23014d)

• [[AWS docs] What is bastion?](https://docs.aws.amazon.com/quickstart/latest/linux-bastion/architecture.html)

• [[AWS docs] NAT GW](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-nat-gateway.html)

• [[AWS docs] Sample VPC use cases](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_Scenarios.html)

• [[video] VPC demo](https://www.youtube.com/watch?v=tD9vDv0uyI8)

• [[AWS docs] FAQ](https://aws.amazon.com/vpc/faqs/?nc=sn&loc=5)

• [[AWS docs] Security Groups](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_SecurityGroups.html)


## What answers to know
1. What VPC configuration was used while you were creating EC2 instances in module 3?
2. What kinds of IP addresses does AWS VPC offer?
3. What happens to different IP address types when an EC2 instance is rebooted, stopped, started?
4. How many elastic IPs is it possible to create per account/region?
5. What is the difference between NAT gateways and NAT instances?
6. What is the difference between security groups and network ACLs?
7. Suppose you’ve assigned a CIDR block to a VPC. Will all the IPs in that block be available for the resources you create in the VPC?
8. What IP ranges is it possible to use for addressing inside one VPC?
9. What does “local” target mean in terms of an AWS routing table?
10. What is bastion in terms of networking?
11. What is elastic network interface?
12. Do you pay for VPC when using EC2 instances?
13. What are the tools for monitoring VPC?
14. How does VPC determine whether to deny/allow a request when both ACLs and security groups specified?
15. How do VPC subnets map onto AZs?
