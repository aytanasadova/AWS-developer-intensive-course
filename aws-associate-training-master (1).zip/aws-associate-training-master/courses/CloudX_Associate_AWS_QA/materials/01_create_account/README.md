# Task #1 – Account creation, roles, billing, alerting

What to read/watch beforehand:
1. https://aws.amazon.com/premiumsupport/knowledge-center/create-and-activate-aws-account/
2. (Optional, 2h 31m) https://www.linkedin.com/learning/amazon-web-services-controlling-cost
3. (Use as a reference) https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/budgets-
managing-costs.html
4. (Optional) https://www.youtube.com/watch?v=ChupgIbZr5Q&feature=youtu.be
5. (Use as a reference) https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html
6. (Use as a reference) https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html
7. https://docs.aws.amazon.com/organizations/latest/userguide/orgs_introduction.html
8. https://docs.aws.amazon.com/general/latest/gr/root-vs-iam.html#aws_tasks-that-require-root
9. https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/tracking-free-tier-usage.html
10. https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_policies_scps.html
11. What should I do if I didn't receive a call from AWS to verify my new account?
12. Video - https://www.youtube.com/watch?v=2XilJFirnWY&ab_channel=ACloudGuru

## What’s given
To successfully complete course, we’ll need AWS account. Some resources are paid, so credit card with reasonable amount of money should be attached. It’s highly recommended to understand and apply cost controlling settings (you can review full course [here](https://www.linkedin.com/learning/amazon-web-services-controlling-cost))

## What to save money on
General recommendations (for this course):

• Use minimum sufficient amount of resources. Performance considered only at the concept level

• Shutdown services/instances that you don’t use Tools that can help:

• AWS Cost Explorer ([link](https://aws.amazon.com/aws-cost-management/aws-cost-explorer/))

• Trusted Advisor ([link](https://aws.amazon.com/premiumsupport/technology/trusted-advisor/))

## What answers to know
1. Do my account contain unnecessary resources that I’m not using right now, but receive charges from them?
2. Why we don’t use root user and create another one instead?
3. How budget reached notifications work?
          