## What’s given

- your AWS account
- an SQS queue from module 8
- the web application from module 8

## What to save money on

- Prefer removing the resources created using the CF template(s) while not working on any practical tasks (the CF template should allow you to quickly re-create them in one shot as needed). 
- Consider [stopping](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_StopInstance.html) your RDS instance while not working on any practical tasks.
- After the demo, consider removing the scheduled CloudWatch event which was created to trigger the lambda function on schedule.
- Also, after the demo, consider removing the lambda function created in sub-task 2 point 6.

## What to do

### Sub-task 1 – create a Lambda for batching upload notifications

1. Create a Lambda function named _\<ProjectName\>-uploads-batch-notifier_:
   - use any preferred programming language 
   - grant the function the basic Lambda permissions as well as permissions for pulling from the _\<ProjectName\>-uploads-notification-queue_ 
   - configure the Lambda to run the code that you wrote for module 7 for transferring SQS messages to SNS (DO NOT FORGET to remove that code from the web-application to avoid functionality duplication)
   - **important**: make sure your Lambda tries polling N messages for a limited period of time (timeout) of 2-3 seconds and does nothing in case no messages found
2. Publish the _\<ProjectName\>-uploads-batch-notifier_.
3. Make 2 or more image uploads using your web application and trigger your Lambda manually. Ensure you got exactly one email with all the publications you’ve just made.

### Sub-task 2 – add Lambda triggers

1. Create an API Gateway endpoint which would allow access only from your IP address and simply trigger the _\<ProjectName\>-uploads-batch-notifier_ Lambda. 
2. Create an endpoint in your web application which would do the same – simply trigger the _\<ProjectName\>-uploads-batch-notifier_ Lambda. 
3. Follow [this tutorial](https://docs.aws.amazon.com/AmazonCloudWatch/latest/events/RunLambdaSchedule.html) to make your Lambda run periodically (let’s say, every 5 minutes). 
4. Make your Lambda logs scheduled/API Gateway/web application calls in such a way that it’s possible to distinguish them in the CloudWatch logs. **Hint** – the tutorial from step 3 makes the Lambda receive messages which have a _detail-type_ field, so it’s possible to fill that field differently for the calls made from the web application and API Gateway endpoint. 
5. Make sure you can see all 3 (scheduled/API Gateway/web application) kinds of Lambda calls in the CloudWatch logs. 
6. Create a separate Lambda function which simply takes in an S3 object creation event and logs the S3 object name. Configure your S3 image bucket to send object creation events to that Lambda.
   - Tip: Since the Lambda handler code is extremely simple, you may code it directly in the AWS Console using any of the available scripting language options.
7. Upload an image to your S3 bucket and ensure you can see the Lambda reacts to this in CloudWatch logs.

## What should I remember?

> - Once you create AWS Account -> Setup Multi-factor Authentication
> - Do NOT share your account
> - Do NOT commit your account Credentials into the Git
> - Terminate/Remove all created resources/services once you finishe Module
> - Please Do not forget to delete NAT Gateway if you used it.
> - Do NOT keep instance running if you don’t use it
> - Carefully keep track of billing and working instances so you don't exceed limits
