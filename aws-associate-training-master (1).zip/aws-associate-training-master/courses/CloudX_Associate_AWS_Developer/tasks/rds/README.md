## What’s given 

1. your AWS account 
2. the CF templates from module 6 
3. the web application from module 4 
4. the S3 bucket from module 3 

## What to save money on 

1. Prefer removing the resources created using the CF template(s) while not working on any practical tasks (the CF template should allow you to quickly re-create them in one shot as needed). 
2. Consider [stopping](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_StopInstance.html) your RDS instance while not working on any practical tasks. 
3. It’s possible to write a script which would both cleanup CF and stop RDS automatically. 

## What to do

1. Create an RDS instance in one of the DB subnets of your VPC. **WARNING: Select a free-tier eligible engine option.**
![](./images/rds-engine.png)
2. Update your web application to include the following functions: 
    - download an image by name 
    - show metadata for the existing images 
    - upload an image 
    - delete an image by name 
    - get metadata for a random image 
3. After uploading some images, make some SQL queries to the RDS instance bypassing the web-application – for example, from the EC2 instances over SSH. 
4. The image metadata should include last update date, name, size in bytes, and file extension. 
5. The overall infrastructure should look like this:
![](./images/rds-app-infrastructure.png)
6. Ensure the following non-functional criteria are met: 
    - the EC2 instance should use IAM roles to access RDS/S3 
    - the EC2 instance should claim the role using the [AWS credentials provider chain](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/credentials.html#credentials-default)
7. Optional: use AWS Identity and Access Management (IAM) database authentication to connect your application to the DB instance. 

 
* *Optional Task is not mandatory for completion this module but highly recommended, if you don’t have a time to complete it - just skip it*

## What should I remember?

> - Once you create AWS Account -> Setup Multi-factor Authentication    
> - Do NOT share your account   
> - Do NOT commit your account Credentials into the Git    
> - Terminate/Remove all created resources/services once you finish Module   
> - Please Do not forget to delete NAT Gateway if you used it.  
> - Do NOT keep instance running if you don’t use it   
> - Carefully keep track of billing and working instances so you don't exceed limits 
