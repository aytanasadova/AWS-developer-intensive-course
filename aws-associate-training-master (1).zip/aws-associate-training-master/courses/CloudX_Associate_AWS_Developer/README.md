# CloudX Associate: AWS Developer
- [Learn](https://learn.epam.com/detailsPage?id=9ffa6ac1-9ed7-4dbb-b81c-a56a55bbc191)
- [Sharepoint contains quiz keys (available for coordinators)](https://epam.sharepoint.com/sites/EPAMCloudXAWSDeveloperCourse/Shared%20Documents/Forms/AllItems.aspx)

## Modules
### Module 1: AWS Essentials for Developers
- [Theory](https://learn.epam.com/detailsPage?id=1841e875-a3a7-4809-9852-6c13d466c523)
### Module 2: Create AWS Account
- [Theory](../../materials/aws_cloud_overview/README.md)
- [Practice](./tasks/create_account/README.md)
### Module 3: IAM
- [Theory](../../materials/security_identity_&_compliance/README.md)
- [Practice](./tasks/iam/README.md)
- [Task reference solution](https://videoportal.epam.com/video/67KlBPaV)
- [Quiz](./quizes/iam.md)
### Module 4: S3
- [Theory](../../materials/storage_services/README.md)
- [Practice](./tasks/s3/README.md)
- [Task reference solution](https://videoportal.epam.com/video/jaNQ2L76)
- [Quiz](./quizes/s3.md)
### Module 5: EC2
- [Theory](../../materials/compute_services/README.md)
- [Practice](./tasks/ec2/README.md)
- [Task reference solution](https://videoportal.epam.com/video/mYQy4dYp)
- [Quiz](./quizes/ec2.md)
### Module 6: VPC
- [Theory](../../materials/networking_dns_and_content_delivery/README.md)
- [Practice](./tasks/vpc/README.md)
- [Task reference solution](https://videoportal.epam.com/video/L7xLgy74)
- [Quiz](./quizes/vpc.md)
### Module 7: Cloud Formation
- [Theory](../../materials/provisioning_services/README.md)
- [Practice](./tasks/cf/README.md)
- [Task reference solution](https://videoportal.epam.com/video/2JwvGXYM)
- [Attachments](./tasks/cf/attachments)
- [Quiz](./quizes/cf.md)
### Module 8: RDS
- [Theory](../../materials/database_services/README.md)
- [Practice](./tasks/rds/README.md)
- [Task reference solution](https://videoportal.epam.com/video/Qa1WmQJk)
- [Attachments](tasks/rds/attachments/rds_attachments.zip)
- [Quiz](./quizes/rds.md)
### Module 9: SNS/SQS
- [Theory](../../materials/serverless/README.md)
- [Practice](./tasks/sns_sqs/README.md)
- [Task reference solution](https://videoportal.epam.com/video/RYpBb57y)
- [Attachments](tasks/sns_sqs/attachments/sns_sqs_attachments.zip)
- [Quiz](./quizes/sns_sqs.md)
### Module 10: Serverless basics
- [Theory](../../materials/serverless/README.md)
- [Practice](./tasks/serverless/README.md)
- [Task reference solution](https://videoportal.epam.com/video/qaBWvRYg)
- [Attachments](tasks/serverless/attachments/serverless_attachments.zip)
- [Quiz](./quizes/serverless.md)
### Module 11: CI/CD tools
- [Theory](../../materials/ci_cd/README.md)
- [Practice](./tasks/ci_cd/README.md)
- [Task reference solution](https://videoportal.epam.com/video/va8WN471)
- [Attachments](tasks/ci_cd/attachments/ci_cd_attachments.zip)
- [Quiz](./quizes/ci_cd.md)
### Module 12: Remove all created resources from AWS account
- Remove all created resources and notify your expert.
