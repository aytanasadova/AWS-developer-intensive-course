# FAQ
## Theory
- #### Which RDS authentication option to choose in which situation (password-based and IAM-based)?
> // TODO
- #### What are the best practices when authenticating to the RDS database?
> // TODO
- #### What ways exist for cross-region synchronization in runtime?
> // TODO
- #### Does Cloud RDS or NoSQL data storage using breaks microservice encapsulation principle?
> // TODO
## Practice
- #### How to configure RDS backup or snapshot downloading into local machine or storage?
> // TODO
