# FAQ
## Theory
- #### Is CodeCommit often used in production, or does it have some underwater issues?
> // TODO
- #### How will the lambda be deployed if DeploymentPreferenceType is not specified? Is there a default value?
> // TODO
- #### How do hooks work in DeploymentPreference and how we can check it?
> // TODO
## Practice
- #### When I try to run CodeBuild, it gives the following error: Build failed to start. The following error occurred: Cannot have more than 0 builds in queue for the account. What could be the cause of this issue?
> // TODO
- #### Is there an option to start EC2 used for CodeBuild only for build time and then stop it automatically?
> // TODO
- #### How to resolve problem with deployment on Lambda? After deploying (project using Maven) in Lambda, we got a ClassNotFoundException. If we upload a jar on Lambda which the same code everything works.
> // TODO
- #### How can DevOps specialists make a rollback if new functionality not meet expected results? Meaning it was successfully deployed, but we need to move to the previous version. How to do that in AWS CloudPipeline?
> // TODO
