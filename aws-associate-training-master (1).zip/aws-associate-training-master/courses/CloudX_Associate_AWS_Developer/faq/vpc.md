# FAQ
## Theory
- #### Was the schema from VPC_Practice.pdf created manually or can I generate the same automatically?
> // TODO
- #### Is there any way to know when a VPC from list was created?  (in security reason, for example)
> // TODO
- #### Which DNS options are available for VPCs? Is it possible to use custom DNS servers?
> // TODO
- #### Are there any limitations when VPC flow log captures information about the IP traffic?
> // TODO
- #### Are there any services/options/solutions how to protect VPC from brute force attacks?
> // TODO
## Practice
- #### How do define subnets CIDR blocks when you create new vpc?
> // TODO
- #### Please provide NACL use cases. We use only Security Groups for our tasks so far.
> // TODO
