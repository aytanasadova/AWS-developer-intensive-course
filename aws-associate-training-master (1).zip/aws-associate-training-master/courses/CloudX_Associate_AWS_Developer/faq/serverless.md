# FAQ
## Theory
- #### What is serverless?
> // TODO
- #### Is SAM a standard for serverless now and is it widely used in prod CI/CDs?
> // TODO
