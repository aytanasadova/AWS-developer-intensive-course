# FAQ
## Theory
- #### What is the difference between Role and Policies?
> // TODO
- #### What is the role type?
>  // TODO
- #### When we need to use RBAC and ABAC in AWS? (maybe some practical examples)
>  // TODO
- #### How AWS Role can be used by mobile application or third party?
> // TODO
- #### What are the benefits of IAM database authentication if you still need to create a user in the database?
> // TODO
- #### What are user groups and security groups in AWS? What’s the difference?
> // TODO
- #### What are the features of AWS service-linked roles, other than it being bound to a specific service? What are the use cases? Why can't you use a simple service role?
> // TODO
