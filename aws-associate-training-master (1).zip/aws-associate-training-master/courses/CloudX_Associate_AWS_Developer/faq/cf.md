# FAQ
## Theory
- #### How are templates written on real projects? Is the designer really helpful?
> // TODO
- #### Is it possible to see the contents of the completed template (ie with user parameters inserted, values imported, etc.)?
> // TODO
- #### Can Terraform completely replace AWS CloudFormation?
> // TODO
- #### Is there an automated way to generate values in "Parameters" section of a CloudFormation Template, which was shown in a video for the current module?
> // TODO
## Practice
- #### Is it possible to automatically create a Cloud Formation template from existing AWS resources?
> // TODO
- #### How is it possible to visualize AWS resources running in an account (in the form of diagrams, as it was done in Theory to the current module)?
> // TODO
