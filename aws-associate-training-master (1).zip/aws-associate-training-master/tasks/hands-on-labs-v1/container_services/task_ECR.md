## Domain: Container Services

### Topic: ECR

### Task: Push nginx docker image in private repository

### Problem to Be Solved

Image storage

### Explanation of the Solution

-   [Repository creation](https://docs.aws.amazon.com/AmazonECR/latest/userguide/repository-create.html)

-   [Pushing a docker image](https://docs.aws.amazon.com/AmazonECR/latest/userguide/docker-push-ecr-image.html)

-   [*Pulling an image*](https://docs.aws.amazon.com/AmazonECR/latest/userguide/docker-pull-ecr-image.html)

### Implementation Details

Prerequisites:

-   Installed [docker](https://www.docker.com/products/docker-desktop)

-   Appropriate IAM polices - **AmazonEC2ContainerRegistryFullAccess** AWS managed policy might be assigned for this task

Private repository creation:

1.  Go to the **Private** tab of **Repositories** under **Amazon ECR** section and click at **Create Repository**.

2.  On the appeared configuration window ensure that **Visibility settings** is set to **Private.** For **Repository name**, enter a unique name for your repository -- ecr-task-{last_name}. Keep other settings by default and click **Create Repository** button.*

Build custom docker Nginx image and push it to the private repository:

1.  Form Dockerfile (in bash `echo \"FROM nginx\" \> Dockerfile`).

2.  Build docker image from Dockerfile with following command: \
    `docker build --file Dockerfile --rm --tag {account_id}.dkr.ecr.{region}.amazonaws.com/ecr-task-{last_name}:nginx`

3.  Retrieve an authentication token and authenticate your Docker client to your registry: \
`aws ecr get-login-password --region {region} | docker login --username AWS --password-stdin {account_id}.dkr.ecr. {region}.amazonaws.com`

4.  Run the following command to push this image to your newly created AWS repository: \
`docker push {account_id}.dkr.ecr.{region}.amazonaws.com/ecr-task-{last_name}:nginx`

### Benefits / Outcomes / Pros and Cons / Summary

This solution might be used as backup solution for your private dicker
registry also it's could be used as source for your ECS load

### Tearing down

Suppress published image and delete created previously repository.
