Compute Services:
- [Amazon EC2 Auto Scaling with EC2 Spot Instances](https://aws.amazon.com/getting-started/hands-on/ec2-auto-scaling-spot-instances/?trk=gs_card)
- [Build a WordPress Website](https://medium.com/@babettelandmesser/install-wordpress-in-aws-ec2-instance-ada5b2db06d2)

Container services:
- [Building web applications based on amazon eks](https://aws-eks-web-application.workshop.aws/en/)

Database services:
- [EC2, AMI, Bastion Host, RDS](https://grapeup.com/blog/the-path-towards-enterprise-level-aws-infrastructure-ec2-ami-bastion-host-rds/)
- [Load Balancing and Application Deployment](https://grapeup.com/blog/the-path-towards-enterprise-level-aws-infrastructure-load-balancing-and-application-deployment/)
- [RDS hands-on lab](https://general-immersionday-tmp.workshop.aws/en/rds.html)
- [Amazon RDS Backup & Restore using AWS Backup](https://aws.amazon.com/getting-started/hands-on/amazon-rds-backup-restore-using-aws-backup/?trk=gs_card)
- [Amazon RDS for SQL Server Workshop](https://catalog.us-east-1.prod.workshops.aws/v2/workshops/897acbd7-8f2e-46ed-8dcd-c97872d5b3ce/en-US/)
- [Amazon RDS for PostgreSQL](https://rdspg.workshop.aws/)
- [Create and Connect to a PostgreSQL Database](https://aws.amazon.com/getting-started/hands-on/create-connect-postgresql-db/)
- [Setting up a Document Database](https://aws.amazon.com/getting-started/hands-on/getting-started-amazon-documentdb-with-aws-cloud9/?trk=gs_card)
- [Create and Connect to a MariaDB Database](https://aws.amazon.com/getting-started/hands-on/create-mariadb-db/)
- [DynamoDB](/materials/07_database_services/docs/DynamoDB_task.docx)
- [Hands-on labs for amazon DynamoDB](https://amazon-dynamodb-labs.workshop.aws/hands-on-labs.html)
- [Create and Query a NoSQL Table](https://aws.amazon.com/getting-started/hands-on/create-nosql-table/)

Functions and API Gateway:
- [Amazon API Gateway tutorials and workshops](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-tutorials.html)
- [Run a Serverless "Hello, World!"](https://aws.amazon.com/getting-started/hands-on/run-serverless-code/)
- [Send Messages Between Distributed Applications with Amazon Simple Queue Service (SQS)](https://aws.amazon.com/getting-started/hands-on/send-messages-distributed-applications/)
- [Orchestrate Queue-based Microservices with AWS Step Functions and Amazon SQS](https://aws.amazon.com/getting-started/hands-on/orchestrate-microservices-with-message-queues-on-step-functions/)
- [Create a 'first-to-respond' task request fanout pattern with Amazon SNS and AWS Step Functions](https://aws.amazon.com/getting-started/hands-on/sns-fanout-messages-step-functions/)
- [Send Fanout Event Notifications](https://aws.amazon.com/getting-started/hands-on/send-fanout-event-notifications/)

Networking, DNS and Content delivery:
- [Vpc hands-on lab](https://general-immersionday-tmp.workshop.aws/en/vpc.html)
- [Networking](https://networking.workshop.aws/)

Observability services:
- [Amazon Cloudwatch Workshop](https://mng.workshop.aws/cloudwatch.html)
- [Building event-driven architectures on AWS](https://catalog.us-east-1.prod.workshops.aws/v2/workshops/63320e83-6abc-493d-83d8-f822584fb3cb/en-US/)
- [One Observability Workshop](https://catalog.us-east-1.prod.workshops.aws/v2/workshops/31676d37-bbe9-4992-9cd1-ceae13c5116c/en-US/)

Provisioning services:
- [AWS Cloudformation Workshop](https://mng.workshop.aws/cloudformation.html)
- [CloudFormation: Creating complex Infrastructure](https://grapeup.com/blog/automating-your-enterprise-infrastructure-part-2-cloud-infrastructure-as-code/)
- [Deploy a reliable multi-tier infrastructure using Cloudformation](https://wellarchitectedlabs.com/reliability/100_labs/100_deploy_cloudformation/)
- [Aws Systems Manager](https://mng.workshop.aws/ssm.html)

Storage Services:
- [Store and Retrieve a File with Amazon S3](https://aws.amazon.com/getting-started/hands-on/backup-files-to-amazon-s3/)
- [S3 hands-on lab](https://general-immersionday-tmp.workshop.aws/en/s3.html)
- [Create and mount an Amazon EFS file system](https://aws.amazon.com/getting-started/hands-on/create-mount-amazon-efs-file-system-on-amazon-ec2-using-launch-wizard/?trk=gs_card)
- [Amazon EFS Backup & Restore using AWS Backup](https://aws.amazon.com/getting-started/hands-on/amazon-efs-backup-and-restore-using-aws-backup/?trk=gs_card)
- [Amazon EBS Backup & Restore using AWS Backup](https://aws.amazon.com/getting-started/hands-on/amazon-ebs-backup-and-restore-using-aws-backup/?trk=gs_card)

