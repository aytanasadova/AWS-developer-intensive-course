## Overview
The practical tasks from the initial version of the AWS Assosiate training developed by a EPAM engineers. 
 Tasks could be used for additional practice in a specific topics.

### Topics:

* Computer services
    * [Launch EC2 instance](./compute_services/Launch_EC2_instance.md)
    * [EC2 scaling](./compute_services/EC2_scaling.md)
* Container services
    * [ECR](./container_services/task_ECR.md)
    * [ECS](./container_services/task_ECS.md)
* Database services
    * [RDS](.//database_services/RDS.md)
* Functions and API Gateway
    * [API Gateway](./functions_and_api_gateway/API_Gateway.md)
    * [Lambda](functions_and_api_gateway/Lambda.md)
* Networking DNS and Content Delivery
    * [VPC](./networking_dns_and_content_delivery/vpc.md)
    * [VPC Flow Logs](./networking_dns_and_content_delivery/flow-logs.md)
    * [Bastion host](./networking_dns_and_content_delivery/ec2.md)
* Observability services
    * [CloudTrail](./observability_services/CloudTrail.md)
    * [EventBridge](./observability_services/AWS_EventBridge_task.md)
* Provisioning services
    * [CloudFormation: EC2 Instance](provisioning_services/cfn-1.md)
    * [CloudFormation: VPC](provisioning_services/cfn-2.md)
    * [CloudFormation: Static Web Site](provisioning_services/cfn-3.md)
    * [SSM Parameter Store](./provisioning_services/ssm_parameter_store.md)
    * [SSM Comand and automation](./provisioning_services/ssm_command_and_automation.md)
* Security Identity and Compliance
    * [IAM roles and policies](./security_identity_&_compliance/Readme.md)
* Storage services
    * [EBS](./storage_services/EBS.md)
* [Collection of external tasks](./external-tasks/Readme.md)
