# Monitoring (Estimated time: 2h)

## Agenda

In this lab we will add monitoring for our used resources. And create dashboard for these metric.

Parameters what will be watching:
- EC2 instances in ASG
  - Average CPU Utilization
- ECS
  - Service CPU Utilization
  - Running Tasks Count
- EFS
  - Client Connections
  - Storage Bytes in Mb
- RDS
  - Database Connections
  - CPU Utilization
  - Storage Read/Write IOPS

Do not for get to add permissions to your services for creating logs.

For this lab you will need whole infrastructure from previous labs in this course. You can easily create it with code that you used. 

The additional resources are recommended to be used for IaC implementation ([Infrastructure as code](./task2_iac.md)). 

<details>
<summary> Terraform </summary>

#### CloudWatch
- [aws_cloudwatch_dashboard](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_dashboard)
</details>

<details>
<summary> AWS CloudFormation </summary>

#### CloudWatch
- [AWS::CloudWatch::Dashboard](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudwatch-dashboard.html)
</details>

## Definition of done

You should provide the output of the following script as the proof of working solution:

```bash
DASHBOARD={your_dashboard_name}
REGION={aws_region} 
aws cloudwatch get-dashboard --dashboard-name $DASHBOARD --region $REGION | jq -c '.DashboardBody | fromjson' | jq '.widgets[] | [.properties.title, .type]'
```


## Clean-up

Do not forget to stop and delete your resources on the end of practice. You can use Tags to locate required resources.
