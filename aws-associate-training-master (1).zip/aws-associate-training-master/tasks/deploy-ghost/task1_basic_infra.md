# Basic Infrastructure (Estimated time: 10h)

## Agenda

In this lab we will create the minimum required infrastructure for our Ghost application and will run it to work.

To achieve this we will need to create some resources:
- Virtual Private Network with 3 subnets in different Avaliability Zones
- Security groups for necessary resources with minimal privileges
- SSH key pair for access to our instances
- LoadBalancer with 1 target group
- IAM role for access to EFS
- Elastic File System for shared content
- Launch Template with user-data script
- Auto Scaling Group
- Bastion host for SSH access to VPC

## Infrastructure Diagram:
![chart](./images/BasicInfrastructure.png)

## Create Network stack

Create network stack for your infrastructure with the following resources:

- VPC: 
  - name=cloudx, cidr=10.10.0.0/16, enable_dns_support=true, enable_dns_hostnames=true
- 3 x Public subnets:
  - name=public_a, cidr=10.10.1.0/24, az=a
  - name=public_b, cidr=10.10.2.0/24, az=b
  - name=public_c, cidr=10.10.3.0/24, az=c
- Internet gateway (name=cloudx-igw) and attach it to appropriate VPC
- Routing table to bind Internet gateway with the Public subnets (name=public_rt)


## Create security groups

Create the following security groups:

- name=bastion, description="allows access to bastion":
  - ingress rule_1: port=22, source={your_ip}, protocol=tcp
  - egress rule_1: allows any destination
- name=ec2_pool, description="allows access to ec2 instances":
  - ingress rule_1: port=22, source_security_group={bastion}, protocol=tcp
  - ingress rule_2: port=2049, source={vpc_cidr}, protocol=tcp
  - ingress rule_3: port=2368, source_security_group={alb}, protocol=tcp
  - egress rule_1: allows any destination
- name=alb, description="allows access to alb":
  - ingress rule_1: port=80, source={your_ip}, protocol=tcp
  - egress rule_1: port=any, source_security_group={ec2_pool}, protocol=any
- name=efs, description="defines access to efs mount points":
  - ingress rule_1: port=2049, source_security_group={ec2_pool}, protocol=tcp
  - egress rule_1: allows any destination to {vpc_cidr}



## Create SSH Key pair

Create custom ssh key-pair to access your ec2 instances:(refer to this [document](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-key-pairs.html#how-to-generate-your-own-key-and-import-it-to-aws))

Uppload it to AWS with name=ghost-ec2-pool

## Create IAM role

Create IAM Role and asosiated IAM Role profile (name=ghost_app) with the following permissions:

```
"ec2:Describe*",
"elasticfilesystem:DescribeFileSystems",
"elasticfilesystem:ClientMount",
"elasticfilesystem:ClientWrite"
```

This IAM role now provides EC2 instances with access to the services. For test purposes it acceptable to allow "any" resource access. You would consider to restrict each service in policy with resource arn(using separate statement for each service) in the real environments.


## Create Elastic File System

- Create EFS file system resource(name=ghost_content)
- Create EFS mount targets for each AZ and assign them with {efs} security group


## Create Application load balancer

- Create Application Load Balancer with 1 target group:
  - target group 1: name=ghost-ec2,port=2368,protocol="HTTP"
-  Create ALB listener: port=80,protocol="HTTP", avalability zone=a,b,c
-  Edit ALB listener rule: action type = "forward",target_group_1_weight=100


## Create Launch Template

In this task you have to author launch tempalate to run Ghost application with UserData script on instance start up. Use Amazon Linux 2 as the base image.

Start up script should do the following:
- Install pre-requirements
- Install, configure and run Ghost application
</br>
  It is important to update 'LB_DNS_NAME' variable to match you ALB DNS name in User data.   
</br>
<details>
  <summary markdown="span">Script example(click to expand):</summary>

```
#!/bin/bash -xe

exec > >(tee /var/log/cloud-init-output.log|logger -t user-data -s 2>/dev/console) 2>&1
### Update this to match your ALB DNS name
LB_DNS_NAME='url.region.elb.amazonaws.com'
###

REGION=$(/usr/bin/curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone | sed 's/[a-z]$//')
EFS_ID=$(aws efs describe-file-systems --query 'FileSystems[?Name==`ghost_content`].FileSystemId' --region $REGION --output text)

### Install pre-reqs
curl -sL https://rpm.nodesource.com/setup_14.x | sudo bash -
yum install -y nodejs amazon-efs-utils
npm install ghost-cli@latest -g

adduser ghost_user
usermod -aG wheel ghost_user
cd /home/ghost_user/

sudo -u ghost_user ghost install local

### EFS mount
mkdir -p /home/ghost_user/ghost/content
mount -t efs -o tls $EFS_ID:/ /home/ghost_user/ghost/content

cat << EOF > config.development.json

{
  "url": "http://${LB_DNS_NAME}",
  "server": {
    "port": 2368,
    "host": "0.0.0.0"
  },
  "database": {
    "client": "sqlite3",
    "connection": {
      "filename": "/home/ghost_user/ghost/content/data/ghost-local.db"
    }
  },
  "mail": {
    "transport": "Direct"
  },
  "logging": {
    "transports": [
      "file",
      "stdout"
    ]
  },
  "process": "local",
  "paths": {
    "contentPath": "/home/ghost_user/ghost/content"
  }
}
EOF

sudo -u ghost_user ghost stop
sudo -u ghost_user ghost start
```

</details>

You can refer to the [application documentation](https://ghost.org/docs/config/)

Сreate Launch Templpate: 
 - name=ghost, instance_type=t2.micro, security_group={ec2_pool}, key_name={ghost-ec2-pool}, userdata={your_startup_script}

To check script you can run single EC2 instance using Launch Template. Don't forget to remove it after testing. 
**Hint**: you can use cloud-init log to examine userData scipt output(/var/log/cloud-init-output.log)


## Create Auto-scaling group

- Create Auto-scaling group and assign it with Launch Template from step 5:
 - name=ghost_ec2_pool
 - avalability zone=a,b,c

- Attach ASG with {ghost-ec2} target group


## Create Bastion

Create bastion host:

- Create EC2 instance:
  - name: bastion
  - instance_type: t2.micro
  - AMI: Amazon Linux 2
  - associate_public_ip_address: true
  - security_group: {bastion}
  - key_name: {ghost-ec2-pool}

- Configure your ssh_config
- Try to connect to your ec2_pool instance by ssh

## Definition of done

You should provide the output of the following script as the proof of working solution:

```bash
REGION={aws_region} 
LB={name_of_your_alb}
LBARN=$(aws elbv2 describe-load-balancers --region $REGION --names $LB | jq -r '.LoadBalancers[].LoadBalancerArn')
for i in  $(aws elbv2 describe-target-groups --load-balancer-arn $LBARN  --region $REGION | jq -r '.TargetGroups[].TargetGroupArn'); \
do \
   aws elbv2 describe-target-health --target-group-arn $i --region $REGION; \
done
```

## Clean-up

Do not forget to stop and delete your resources on the end of practice. You can use Tags to locate required resources.
