# Second target group (Estimated time: 10h)

## Agenda

In this lab we will use additional platform for launching Ghost application. We will be able to compare different architectures, pros and cons.

To achieve this we will need to create and update some resources:
- Subnets and ECS subnets groups
- Security group
- ECR
- IAM
- Update ALB
- ECS, task definition and service


> **<span>&#9888;</span> Warning!!!**
> - There are no free-tier for Fargate. For matter of learn you can run it as long as you need (to get logs and metrics).
> - There are no free-tier for VPC Endpoints. For matter of learn you can run it as long as you need (to get logs and metrics).


For this lab you will need basic infrastructure from [Basic Infrastructure](./task1_basic_infra.md) and [External DataBase](./task3_db.md). You can easly create it with code from [Infrastructure as code](./task2_iac.md). 

The additional resources are recommended to be used for IaC implementation ([Infrastructure as code](./task2_iac.md)). 

<details>
<summary> Terraform </summary>

#### ECS & ECR
- [aws_ecr_repository](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecr_repository)
- [aws_ecs_cluster](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecs_cluster)
- [aws_ecs_service](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecs_service)
- [aws_ecs_task_definition](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ecs_task_definition)
</details>

<details>
<summary> AWS CloudFormation </summary>

#### ECS & ECR
- [AWS::ECR::Repository](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecr-repository.html)
- [AWS::ECS::Cluster](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-cluster.html)
- [AWS::ECS::Service](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-service.html)
- [AWS::ECS::TaskDefinition](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ecs-taskdefinition.html)
</details>

## Infrastructure Diagram:
![chart](./images/FullInfrastructure.png)

## 1 - Add private subnets for ECS Fargate

- 3 x ECS subnets(private):
  - name=private_a, cidr=10.10.10.0/24, az=a
  - name=private_b, cidr=10.10.11.0/24, az=b
  - name=private_c, cidr=10.10.12.0/24, az=c
- Attach ECS private subnets to private route table  (name=private_rt, check [External DataBase](./task3_db.md))

## 2 - Add security groups for ECS Fargate

Add the following security group:

- name=fargate_pool, description="Allows access for Fargate instances":
  - ingress rule_1: port=2049, source_security_group={efs}, protocol=tcp
  - ingress rule_2: port=2368, source_security_group={alb}, protocol=tcp
  - egress rule_1: allows any destination

Update DB, EFS security groups:
- name=efs
  - add ingress rule: port=2049, source_security_group={fargate_pool}, protocol=tcp
- name=mysql
  - add ingress rule: port=3306, source_security_group={fargate_pool}, protocol=tcp

## 3 - Create ECR

Create ECR related resources:
- ECR repository:
  - name=ghost, Tag immutability = disabled, Scan on push = disabled, KMS encryption = disabled

- \*Upload **ghost:4.12** image into **ghost** ECR
  1. Pull public accessable **ghost:4.12** docker image
  1. Login into <account_id>.dkr.ecr.\<region>.amazonaws.com
  1. Tag pulled image with **<account_id>.dkr.ecr.\<region>.amazonaws.com/ghost:4.12** 
  1. Push **<account_id>.dkr.ecr.\<region>.amazonaws.com/ghost:4.12** 

\* - Image size is expected to be less than 500 MB

## 4 - Create IAM role

Create IAM Role and associated IAM Role profile (name=ghost_ecs) with the following permissions:

```
"ecr:GetAuthorizationToken",
"ecr:BatchCheckLayerAvailability",
"ecr:GetDownloadUrlForLayer",
"ecr:BatchGetImage",
"elasticfilesystem:DescribeFileSystems",
"elasticfilesystem:ClientMount",
"elasticfilesystem:ClientWrite"
```

This IAM role now provides ECS Tasks with access to the services. For test purposes it acceptable to allow "any" resource access. You would consider to restrict each service in policy with resource arn(using separate statement for each service) in the real environments.

## 5 - Update Application load balancer

- Update Application Load Balancer with second target group:
  - target group 2: name=ghost-fargate,port=2368,protocol="HTTP"
- Update ALB listener rule: 
  - Action type = "forward"
  - Target_group_1_weight=50
  - Target_group_2_weight=50

>  The AWS Console does not allow you to attach an existing target group unless the listener has a rule that redirects 100% of traffic to the Fargate target group (with IP type)
>
>  **Workaround**
>  1. Change the listener rule (or add a new one) to forward 100% of traffic to the fargate target group. 
>  1. Create a fargate task 
>  1. Change the rule back to 50/50 (or remove the extra rule)

## 6 - VPC endpoints
  
Fargate tasks will have no Public IP and cannot access AWS services via Internet. Therefore you have to configure VPC Endpoints for the following services: SSM, ECR, EFS, S3, CloudWatch and CloudWatch logs services. You have to assign all interface type VPC endpoints with {vpc_endpoint} security group. Gateway type VPC endpoint should be assigned with private network routing table:{private_rt}.

## 7 - Create ECS

Create ECS related resources:
- ECS cluster
  - name=ghost, containerInsights=enabled
- Task definition
  - Name = task_def_ghost
  - Requires compatibilities = FARGATE
  - Task role = Task execution role = {arn of IAM role}
  - Network mode = awsvpc
  - Memory = 1024 (recommended)
  - CPU = 256 (recommended)
  - Volume name = ghost_volume, EFS volume configuration = {efs_id}
  - Container definition. 
  <details>
  <summary>Template for container definition</summary>

  You can use **Configure via JSON** option to setup container definition.
  Please, update the template with correct values for **PASS, ECR_IMAGE, DB_NAME, DB_USER, DB_URL**

    ```json
    [
        {
        "name": "ghost_container",
        "image": "${ECR_IMAGE}",
        "essential": true,
        "environment": [
            { "name" : "database__client", "value" : "mysql"},
            { "name" : "database__connection__host", "value" : "${DB_URL}"},
            { "name" : "database__connection__user", "value" : "${DB_USER}"},
            { "name" : "database__connection__password", "value" : "${PASS}"},
            { "name" : "database__connection__database", "value" : "${DB_NAME}"}
        ],
        "mountPoints": [
            {
                "containerPath": "/var/lib/ghost/content",
                "sourceVolume": "ghost_volume"
            }
        ],
        "portMappings": [
            {
            "containerPort": 2368,
            "hostPort": 2368
            }
        ]
        }
    ] 
    ```

  </details>

- Service
  - Service name = ghost
  - Launch type = FARGATE 
  - Task Definition = {task_def_ghost}
  - Cluster = {ghost}
  - Number of tasks = 1
  - Application Load balancer 
    - Use one create in [Basic Infrastructure](../basic_info/README.md)
    - Target group = {ghost-fargate}
  - Assign public ip = false
  - Subnets = list of private ECS subnets 
  - Security groups = {fargate_pool}
  
## Definition of done

You should provide the output of the following script as the proof of working solution:

```bash
REGION={aws_region} 
LB={name_of_your_alb}
LBARN=$(aws elbv2 describe-load-balancers --region $REGION --names $LB | jq -r '.LoadBalancers[].LoadBalancerArn')
for i in  $(aws elbv2 describe-target-groups --load-balancer-arn $LBARN  --region $REGION | jq -r '.TargetGroups[].TargetGroupArn'); \
do \
   aws elbv2 describe-target-health --target-group-arn $i --region $REGION; \
done
```

## Clean-up

Do not forget to stop and delete your resources on the end of practice. You can use Tags to locate required resources.
