# Problem statement

Application solution requires highly-available setup, utilizing caching for quick delivery of content. It also has to support Red/Black deployment and allow users to access the site without typing .html.
Additionally, there is a backend application, that has multiple APIs and must be setup with serverless approach.

# Solutioning approach

- Have S3 as a storage for content
- Use Cloudfront to cache and quickly return content across the world
- Enable Cloudfront Functions for rewriting URL paths
- Utilize S3 prefixes for red/black deployment
- Lambda function to switch origin paths on new folder creation
- Lambda functions for APIs
- API Gateway in front of backend Lambda functions for route configuration

# Pre-requirements

- Activated AWS account
- All modules from CloudX AWS DevOps course completed

## Initial setup

1. Create S3 bucket

- Name - my-app-${name-surname}
- Public access - disabled

2. Upload website files
 - Create folder A in S3 bucket  
 - Upload web files from folder A in repo to folder A in S3 bucket

3. Create New cloudfront distribution

- Origin - my-app-${name_surname} bucket 
- Origin path - folder A

Verification - going to $Cloudfront_domain_name/test.html returns 403 error

## Permissions setup

1. Create [Origin Access Identity](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-restricting-access-to-s3.html) to allow Cloudfront to read bucket contents

- Name - my-app-read

2. [Allow OAI access to S3 using S3 policy](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-restricting-access-to-s3.html#private-content-updating-s3-bucket-policies)

Verification - Going to $CLOUDFRONT_DOMAIN_NAME/test.html returns proper content

## Red/Black setup

1. Upload website files
 - Create folder B in S3 bucket  
 - Upload web files from folder B in repo to folder B in S3 bucket

2. Update distribution
 - Origin Path - Folder B

3. Observe page not changed

4. Invalidate cache
 - Path - /*

Verification - $CLOUDFRONT_DOMAIN_NAME/test.html is now taken from folder B instead of folder A

## Cloudfront tweaks

1. Setup custom error 404 page
- Error code - 404
- Code to return - 404
- Custom page - error.html

Verification - non-existent pages return custom 404 page instead

3. Add Cloudfront function to access pages without .html
 - Function location - redirect/redirect.js
 - Trigger - viewer-request

Verification - going to $CLOUDFRONT_DOMAIN_NAME/test properly redirects to test.html

## Backend Application setup

1. Deploy two Lambda functions
Lambda #1
- Code location - app/api.py
- Function name - my-api

Lambda #2
- Code location - app/api.py(update the line 5 to change from "number one" to "number two")
- Function name - my-api-2

Note: you might need to setup an IAM role to have Lambda create logs in Cloudwatch

## API Gateway configuration

1. Setup API Gateway
Name - my-api
CORS configuration - Access-Control-Allow-Origin = * 
Route #1
- Integration - Lambda #1
- Route - /my-api

Route #2
- Integration - Lambda #2
- Route - /my-api-2

Verification - Going to $API_GW_LINK/my-api should return proper response

## Frontend application setup

1. Upload website files
 - Upload web files from folder frontend in repo to current origin path in S3

Verification - going to $CLOUDFRONT_DOMAIN_NAME/front and clicking on any of the buttons should correctly update the page
