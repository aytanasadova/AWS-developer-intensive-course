function handler(event) {
  var request = event.request;
  var uri = request.uri;
  var isIndex = uri === '/';
  if (isIndex) {
    request.uri += 'index.html';
  } else {
    if (uri.endsWith('.js')){
      return request;
    }
    request.uri += '.html';
  }
  return request;
}
