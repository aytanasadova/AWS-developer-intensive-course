# Certification preparation for CloudX students
 We highly recommend to study the materials below in addition to the program module.

### General materials about the deployment
- [Elastic Beanstalk](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/Welcome.html)

### AWS Certified Developer - Associate certification
- [AWS CodeStar](https://docs.aws.amazon.com/codestar/latest/userguide/welcome.html)
- [Redeploy and roll back a deployment with CodeDeploy](https://docs.aws.amazon.com/codedeploy/latest/userguide/deployments-rollback-and-redeploy.html)
- [Elastic Beanstalk: dashboard](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/environments-health.html)
- [Elastic Beanstalk: Package the application](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/applications-sourcebundle.html)
- [Elastic Beanstalk: Deployment policies](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/using-features.rolling-version-deploy.html)
- [Elastic Beanstalk: Managing environments](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/using-features.managing.html)
- [Elastic Beanstalk: Managing application versions](https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/applications-versions.html)

### AWS Certified SysOps Administrator - Associate certification
- [EC2 Image Builder](https://docs.aws.amazon.com/imagebuilder/latest/userguide/what-is-image-builder.html)
- [AWS Resource Access Manager](https://docs.aws.amazon.com/ram/latest/userguide/what-is.html)
- [CloudFormation StackSets](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/what-is-cfnstacksets.html)
- [Deployment scenarios](https://docs.aws.amazon.com/whitepapers/latest/overview-deployment-options/deployment-strategies.html)
- [AWS OpsWorks](https://docs.aws.amazon.com/opsworks/latest/userguide/welcome.html)
