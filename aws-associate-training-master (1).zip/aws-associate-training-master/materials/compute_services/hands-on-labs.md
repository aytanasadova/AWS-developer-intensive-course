## Hands-on Labs. Compute Services.
### Basic level:
- [AWS General Immersion Day: Compute Basic](https://catalog.workshops.aws/general-immersionday/en-US/basic-modules/10-ec2)
- [Amazon EC2 Auto Scaling with EC2 Spot Instances](https://aws.amazon.com/ru/getting-started/hands-on/ec2-auto-scaling-spot-instances/?trk=gs_card)

### Advanced level:
- [Amazon EC2 Workshop](https://ec2-immersionday.workshop.aws/)