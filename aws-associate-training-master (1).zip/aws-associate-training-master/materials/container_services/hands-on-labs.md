## Hands-on Labs. Container Services.
### Basic level:
- [AWS Containers Immersion Day](https://catalog.us-east-1.prod.workshops.aws/workshops/ed1a8610-c721-43be-b8e7-0f300f74684e/en-US/)
- [Building Web Applications Based On Amazon EKS](https://catalog.us-east-1.prod.workshops.aws/workshops/9c0aa9ab-90a9-44a6-abe1-8dff360ae428/en-US)

### Advanced level:
- [Amazon ECS Workshop](https://ecsworkshop.com/)
- [Amazon ECS Anywhere Basic Workshop](https://catalog.us-east-1.prod.workshops.aws/workshops/cce3c61d-30d2-4fcc-8265-8aeb87eb53ae/en-US/)