## Hands-on Labs. Database Services.
### Basic level:
- [AWS General Immersion Day: RDS Basic](https://catalog.workshops.aws/general-immersionday/en-US/basic-modules/50-rds)
- [Amazon RDS Backup & Restore Using AWS Backup](https://aws.amazon.com/getting-started/hands-on/amazon-rds-backup-restore-using-aws-backup/?trk=gs_card)

### Advanced level:
- [Setting Up A Document Database](https://aws.amazon.com/getting-started/hands-on/getting-started-amazon-documentdb-with-aws-cloud9/?trk=gs_card)
- [Hands-on Labs For Amazon DynamoDB](https://amazon-dynamodb-labs.workshop.aws/hands-on-labs.html)
- [Create And Query A NoSQL Table](https://aws.amazon.com/getting-started/hands-on/create-nosql-table/)
- [Move To Managed Databases](https://aws.amazon.com/getting-started/hands-on/move-to-managed/?trk=gs_card)
- [Amazon RDS For SQL Server Workshop](https://catalog.us-east-1.prod.workshops.aws/workshops/897acbd7-8f2e-46ed-8dcd-c97872d5b3ce/en-US/)
- [Amazon RDS For PostgreSQL](https://catalog.us-east-1.prod.workshops.aws/workshops/2a5fc82d-2b5f-4105-83c2-91a1b4d7abfe/en-US)
- [Create And Connect To A MariaDB Database](https://aws.amazon.com/getting-started/hands-on/create-mariadb-db/)