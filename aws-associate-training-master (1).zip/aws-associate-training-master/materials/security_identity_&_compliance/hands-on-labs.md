## Hands-on Labs. Security Identity And Compliance Services.
### Basic level:
- [AWS General Immersion Day: IAM Basic](https://catalog.workshops.aws/general-immersionday/en-US/basic-modules/30-iam)
- [Use The New Visual Editor To Create And Modify Your AWS IAM Policies](https://aws.amazon.com/ru/blogs/security/use-the-new-visual-editor-to-create-and-modify-your-aws-iam-policies/)

### Advanced level:
- [Key Management: KMS](https://catalog.us-east-1.prod.workshops.aws/workshops/aad9ff1e-b607-45bc-893f-121ea5224f24/en-US/keymanagement-kms)