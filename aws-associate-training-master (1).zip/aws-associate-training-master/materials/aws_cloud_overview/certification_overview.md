# Certification preparation for CloudX students
 We highly recommend to study the materials below in addition to the program module.

### AWS Certified Developer - Associate certification
- [AWS SDK](https://docs.aws.amazon.com/sdkref/latest/guide/overview.html)
