# Practice

- [EBS](EBS.md)

Additional:
- [Store and Retrieve a File with Amazon S3](https://aws.amazon.com/getting-started/hands-on/backup-files-to-amazon-s3/)
- [S3 hands-on lab](https://general-immersionday-tmp.workshop.aws/en/s3.html)
- [Create and mount an Amazon EFS file system](https://aws.amazon.com/getting-started/hands-on/create-mount-amazon-efs-file-system-on-amazon-ec2-using-launch-wizard/?trk=gs_card)
- [Amazon EFS Backup & Restore using AWS Backup](https://aws.amazon.com/getting-started/hands-on/amazon-efs-backup-and-restore-using-aws-backup/?trk=gs_card)
- [Amazon EBS Backup & Restore using AWS Backup](https://aws.amazon.com/getting-started/hands-on/amazon-ebs-backup-and-restore-using-aws-backup/?trk=gs_card)

