## Hands-on Labs. Monitoring Services.
### Basic level:
- [AWS General Immersion Day: Monitoring Basic](https://catalog.workshops.aws/general-immersionday/en-US/basic-modules/40-monitoring)

### Advanced level:
- [Building Event-driven Architectures On AWS](https://catalog.us-east-1.prod.workshops.aws/workshops/63320e83-6abc-493d-83d8-f822584fb3cb/en-US/)
- [One Observability Workshop](https://catalog.us-east-1.prod.workshops.aws/workshops/31676d37-bbe9-4992-9cd1-ceae13c5116c/en-US/)
