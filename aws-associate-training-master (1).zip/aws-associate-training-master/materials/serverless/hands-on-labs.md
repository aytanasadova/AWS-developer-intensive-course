## Hands-on Labs. Functions And API Gateway Services.
### Basic level:
- [Run A Serverless "Hello, World!"](https://aws.amazon.com/getting-started/hands-on/run-serverless-code/)

### Advanced level:
- [Send Messages Between Distributed Applications](https://aws.amazon.com/getting-started/hands-on/send-messages-distributed-applications/)
- [Amazon API Gateway Tutorials And Workshops](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-tutorials.html)
- [Orchestrate Queue-based Microservices](https://aws.amazon.com/getting-started/hands-on/orchestrate-microservices-with-message-queues-on-step-functions/)
- [Create A 'first-to-respond' Task Request Fanout Pattern](https://aws.amazon.com/getting-started/hands-on/sns-fanout-messages-step-functions/)
- [Send Fanout Event Notifications](https://aws.amazon.com/getting-started/hands-on/send-fanout-event-notifications/)
