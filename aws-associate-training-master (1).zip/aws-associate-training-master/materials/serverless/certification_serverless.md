# Certification preparation for CloudX students
 We highly recommend to study the materials below in addition to the program module.

## General materials about the security
- [Amazon API Gateway](https://docs.aws.amazon.com/apigateway/latest/developerguide/welcome.html)
- [Amazon API Gateway caching mechanism](https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-caching.html)

### AWS Certified Developer - Associate certification
- [AWS Serverless Application Model](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/what-is-sam.html)
- [Amazon Kinesis](https://docs.aws.amazon.com/streams/latest/dev/introduction.html)

### AWS Certified SysOps Administrator - Associate certification
